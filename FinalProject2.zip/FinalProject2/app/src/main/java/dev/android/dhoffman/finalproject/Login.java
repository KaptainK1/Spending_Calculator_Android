package dev.android.dhoffman.finalproject;

import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.Gravity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.Toolbar;

import static android.view.ViewGroup.LayoutParams.MATCH_PARENT;
import static android.view.ViewGroup.LayoutParams.WRAP_CONTENT;


public class Login extends AppCompatActivity{

    private boolean fabExpanded = false;
    private FloatingActionButton fabSettings;
    private LinearLayout layoutFabSave;
    private LinearLayout layoutFabDelete;
    private LinearLayout layoutFabReset;
    protected static String loginUser;
    public String dbUsername = MainActivity.dbBudget.dbUserEntry.TABLE_NAME;
    public String columnUsername = dbUsername + "." + MainActivity.dbBudget.dbUserEntry.COLUMN_NAME_USERNAME;
    public String columnPassword = dbUsername + "." + MainActivity.dbBudget.dbUserEntry.COLUMN_NAME_PASSWORD;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        android.support.v7.widget.Toolbar toolbar = (android.support.v7.widget.Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        fabSettings = (FloatingActionButton) this.findViewById(R.id.fabSetting);

        layoutFabSave = (LinearLayout) this.findViewById(R.id.layoutFabSave);
        layoutFabDelete = (LinearLayout) this.findViewById(R.id.layoutFabDelete);
        layoutFabReset = (LinearLayout) this.findViewById(R.id.layoutFabReset);

        //When main Fab (Settings) is clicked, it expands if not expanded already.
        //Collapses if main FAB was open already.
        //This gives FAB (Settings) open/close behavior
        fabSettings.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (fabExpanded == true){
                    closeSubMenusFab();
                } else {
                    openSubMenusFab();
                }
            }
        });
        //Only main FAB is visible in the beginning
        closeSubMenusFab();
    }

    //closes FAB submenus
    private void closeSubMenusFab(){
        layoutFabSave.setVisibility(View.INVISIBLE);
        layoutFabDelete.setVisibility(View.INVISIBLE);
        layoutFabReset.setVisibility(View.INVISIBLE);
        fabSettings.setImageResource(R.drawable.ic_create_black_24dp);
        fabExpanded = false;
    }

    //Opens FAB submenus
    private void openSubMenusFab(){
        layoutFabSave.setVisibility(View.VISIBLE);
        layoutFabDelete.setVisibility(View.VISIBLE);
        layoutFabReset.setVisibility(View.VISIBLE);
        //Change settings icon to 'X' icon
        fabSettings.setImageResource(R.drawable.ic_close_black_24dp);
        fabExpanded = true;
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    public void showMessage(String message){
        Context context = getApplicationContext();
        CharSequence text = message;
        int duration = Toast.LENGTH_SHORT;
        Toast toast = Toast.makeText(context, text, duration);
        toast.show();
    }


    //set the username and password to login. This could be replaced with a DB that would keep all usernames and passwords
    protected static String currentPassword="password";
    protected static String currentUsername = "admin";

    public void onNext(View view) {

        EditText edit = findViewById(R.id.enterPassword);
        EditText editUsername = findViewById(R.id.enterUsername);
        String strUsername = editUsername.getText().toString();
        String strPassword = edit.getText().toString();

        MainActivity.budgetDbHelper dbHelper = new MainActivity.budgetDbHelper(getApplicationContext());
        // Gets the data repository in read mode
        SQLiteDatabase db = dbHelper.getReadableDatabase();

        String selectUsername = ("SELECT " + columnUsername + " FROM " + dbUsername + " WHERE " +
                columnUsername + " ='" + strUsername+"'");

        String selectPassword = ("SELECT " + columnPassword + " FROM " + dbUsername + " WHERE " +
                columnPassword + " ='" + strPassword +"'");

        Cursor cursorUsername = db.rawQuery(selectUsername, null);
        cursorUsername.moveToFirst();
        String strDBUsername = cursorUsername.getString(0);
        cursorUsername.close();


        Cursor cursorPassword = db.rawQuery(selectPassword, null);
        cursorPassword.moveToFirst();
        String strDBPassword = cursorPassword.getString(0);
        cursorPassword.close();


        if (strDBUsername.equals(strUsername) && strDBPassword.equals(strPassword)){
            Intent intent = new Intent(this,MainActivity.class);
            startActivity(intent);
            loginUser=strUsername;
        } else {
            showMessage("Entered Wrong Username or Password");
        }
    }


    public void onReset(View view){
        Intent intent = new Intent(this, resetPassword.class);
        startActivity(intent);
    }

    public void onDeleteUser(View view){
        showMessage("User Deleted");
        //Need to handle deleting user with active data
    }

    public void onAddUser(View view) {
        showMessage("User Added");

        EditText edit = findViewById(R.id.enterPassword);
        EditText editUsername = findViewById(R.id.enterUsername);
        String strUsername = editUsername.getText().toString();
        String strPassword = edit.getText().toString();

        if (strUsername.equals("") || strPassword.equals("")) {
            showMessage("Enter a Username and Password");
            return;
        } else {

            MainActivity.budgetDbHelper dbHelper = new MainActivity.budgetDbHelper(getApplicationContext());
            // Gets the data repository in write mode
            SQLiteDatabase db = dbHelper.getWritableDatabase();

            //using a select statement to see if the user already exists
            String selectQuery = ("SELECT " + columnUsername + " FROM " + dbUsername+ " WHERE " +
                    columnUsername +
                    " ='" + strUsername+ "'");

            Cursor cursor = db.rawQuery(selectQuery, null);
            String strDBUsername="";

            if (cursor.moveToFirst()) {
                //do loop to handle each return of the select query
                do {
                    //add the three necessary columns to return in a String array
                    strDBUsername = cursor.getString(0);
                } while (cursor.moveToNext());
                cursor.close();
            }

            if (strUsername.equals(strDBUsername)) {
                showMessage("User already exists");
                return;
            } else {
                // Create a new map of values, where column names are the keys
                ContentValues values = new ContentValues();
                values.put(MainActivity.dbBudget.dbUserEntry.COLUMN_NAME_USERNAME, strUsername);
                values.put(MainActivity.dbBudget.dbUserEntry.COLUMN_NAME_PASSWORD, strPassword);
                //Check to make sure data is entered
                long newRowId =
                        db.insert(dbUsername, null, values);
                isFinishing();
                showMessage("User Added");
            }
            cursor.close();
        }
    }

    public void onResetPassword(View view){

    }

}
